disableShrimpHUD = false

function onCreate()
	initSaveData('shrimpleHUD', 'shrimpleHUD')
	if getDataFromSave('shrimpleHUD', 'hudStyle') ~= 'vanilla' and getDataFromSave('shrimpleHUD', 'hudStyle') ~= 'shrimple' then
		setDataFromSave('shrimpleHUD', 'hudStyle', 'vanilla')
	end
	flushSaveData('shrimpleHUD')
end

function onCreatePost() -- ill clean this up later if im able to lolol
	if not disableShrimpHUD then
		if getDataFromSave('shrimpleHUD', 'hudStyle') == 'vanilla' then
			if stringStartsWith(version, '0.6') then
				makeLuaText('scoreText', 'SCORE: '..score..' ['..ratingFC..']', 200, getProperty('healthBar.x') + 397.5, getProperty('healthBar.y') - 25)
			elseif stringStartsWith(version, '0.7') then
				makeLuaText('scoreText', 'SCORE: '..score..' ['..ratingFC..']', 200, getProperty('healthBar.x') + 402.5, getProperty('healthBar.y') - 20)
			end
			setTextAlignment('scoreText', 'right')
		elseif getDataFromSave('shrimpleHUD', 'hudStyle') == 'shrimple' then
			if downscroll then
				if stringStartsWith(version, '0.6') then
					setProperty('healthBarBG.y', 35.75)
				end
				setProperty('healthBar.y', 35.75)
			else
				if stringStartsWith(version, '0.6') then
					setProperty('healthBarBG.y', 684.25)
				end
				setProperty('healthBar.y', 684.25)
			end
			
			if stringStartsWith(version, '0.6') then
				if downscroll then
					makeLuaText('scoreText', 'SCORE: '..score..'\nACCURACY: 0% ['..ratingFC..']\nMISSES: '..misses..'', 0, getProperty('healthBar.x') - 5, getProperty('healthBar.y') + 15)
				else
					if botPlay then
						makeLuaText('scoreText', 'SCORE: '..score..'\nACCURACY: 0% ['..ratingFC..']\nMISSES: '..misses..'', 0, getProperty('healthBar.x') - 5, getProperty('healthBar.y') - 25)
					else
						makeLuaText('scoreText', 'SCORE: '..score..'\nACCURACY: 0% ['..ratingFC..']\nMISSES: '..misses..'', 0, getProperty('healthBar.x') - 5, getProperty('healthBar.y') - 55)
					end
				end
			elseif stringStartsWith(version, '0.7') then
				if downscroll then
					makeLuaText('scoreText', 'SCORE: '..score..'\nACCURACY: 0% ['..ratingFC..']\nMISSES: '..misses..'', 0, getProperty('healthBar.x'), getProperty('healthBar.y') + 20)
				else
					if botPlay then
						makeLuaText('scoreText', 'SCORE: '..score..'\nACCURACY: 0% ['..ratingFC..']\nMISSES: '..misses..'', 0, getProperty('healthBar.x'), getProperty('healthBar.y') - 20)
					else
						makeLuaText('scoreText', 'SCORE: '..score..'\nACCURACY: 0% ['..ratingFC..']\nMISSES: '..misses..'', 0, getProperty('healthBar.x'), getProperty('healthBar.y') - 50)
					end
				end
			end
			
			setProperty('iconP1.visible', false)
			setProperty('iconP2.visible', false)
			setTextAlignment('scoreText', 'left')
		end
		
		setProperty('scoreTxt.visible', false)
		scaleObject('timeBar', 0.5, 1)
		setObjectOrder('timeBar', getObjectOrder('iconP1') + 1)
		setObjectOrder('timeTxt', getObjectOrder('timeBar') + 1)
		
		if stringStartsWith(version, '0.6') then -- god this is so ass
			if getDataFromSave('shrimpleHUD', 'hudStyle') == 'shrimple' and not downscroll then
				setProperty('timeBar.y', getProperty('healthBar.y') - 20)
				setProperty('timeTxt.y', getProperty('healthBar.y') - 25)
			else
				setProperty('timeBar.y', getProperty('healthBar.y') + 20)
				setProperty('timeTxt.y', getProperty('healthBar.y') + 16)
			end
			scaleObject('timeBarBG', 0.5, 1)
			setProperty('timeBar.x', getProperty('healthBar.x') + 400)
			setProperty('timeTxt.x', getProperty('healthBar.x') + 192.5)
		elseif stringStartsWith(version, '0.7') then
			if getDataFromSave('shrimpleHUD', 'hudStyle') == 'shrimple' and not downscroll then
				setProperty('timeBar.y', getProperty('healthBar.y') - 30)
				setProperty('timeTxt.y', getProperty('healthBar.y') - 20)
			else
				setProperty('timeBar.y', getProperty('healthBar.y') + 10)
				setProperty('timeTxt.y', getProperty('healthBar.y') + 20)
			end
			setProperty('timeBar.x', getProperty('healthBar.x') + 200)
			setProperty('timeTxt.x', getProperty('healthBar.x') + 195)
		end
		
		if botPlay then
			setProperty('grpNoteSplashes.visible', false)
			setProperty('showComboNum', false)
			setProperty('showRating', false)
			setProperty('botplayTxt.visible', false)
			setTextString('scoreText', '[BOTPLAY]')
		end
		
		addLuaText('scoreText')
		setTextAlignment('timeTxt', 'right')
		setTextSize('timeTxt', getTextSize('scoreText'))
	end
end

function onUpdate()
	if keyboardJustPressed('NINE') and not disableShrimpHUD then
		if getDataFromSave('shrimpleHUD', 'hudStyle') == 'vanilla' then
			if downscroll then
				setProperty('healthBar.y', 35.75)
				if stringStartsWith(version, '0.6') then
					setProperty('healthBarBG.y', 35.75)
					setProperty('scoreText.y', getProperty('healthBar.y') + 15)
				elseif stringStartsWith(version, '0.7') then
					setProperty('scoreText.y', getProperty('healthBar.y') + 20)
				end
			else
				setProperty('healthBar.y', 684.25)
				if stringStartsWith(version, '0.6') then
					setProperty('healthBarBG.y', 684.25)
					if botPlay then
						setProperty('scoreText.y', getProperty('healthBar.y') - 25)
					else
						setProperty('scoreText.y', getProperty('healthBar.y') - 55)
					end
				elseif stringStartsWith(version, '0.7') then
					if botPlay then
						setProperty('scoreText.y', getProperty('healthBar.y') - 20)
					else
						setProperty('scoreText.y', getProperty('healthBar.y') - 50)
					end
				end
			end
			
			if stringStartsWith(version, '0.6') then
				setProperty('scoreText.x', getProperty('healthBar.x') - 5)
			elseif stringStartsWith(version, '0.7') then
				setProperty('scoreText.x', getProperty('healthBar.x'))
			end
			
			if not botPlay then
				setTextString('scoreText', 'SCORE: '..score..'\nACCURACY: '..round((getProperty('ratingPercent') * 100), 2)..'% ['..ratingFC..']\nMISSES: '..misses..'')
			end
			-- FUN!!!!!!!
			setDataFromSave('shrimpleHUD', 'hudStyle', 'shrimple')
			setProperty('iconP1.visible', false)
			setProperty('iconP2.visible', false)
			setTextWidth('scoreText', 0)
			setTextAlignment('scoreText', 'left')
			debugPrint('Set HUD style to Shrimple')
		elseif getDataFromSave('shrimpleHUD', 'hudStyle') == 'shrimple' then
			if downscroll then
				if stringStartsWith(version, '0.6') then
					setProperty('healthBarBG.y', 79.2)
				end
				setProperty('healthBar.y', 79.2)
			else
				if stringStartsWith(version, '0.6') then
					setProperty('healthBarBG.y', 640.8)
				end
				setProperty('healthBar.y', 640.8)
			end
			
			if stringStartsWith(version, '0.6') then
				setProperty('scoreText.x', getProperty('healthBar.x') + 397.5)
				setProperty('scoreText.y', getProperty('healthBar.y') - 25)
			elseif stringStartsWith(version, '0.7') then
				setProperty('scoreText.x', getProperty('healthBar.x') + 402.5)
				setProperty('scoreText.y', getProperty('healthBar.y') - 20)
			end
			
			if not botPlay then
				setTextString('scoreText', 'SCORE: '..score..' ['..ratingFC..']')
			end
			-- FUN!!!!!!! 2
			setDataFromSave('shrimpleHUD', 'hudStyle', 'vanilla')
			setProperty('iconP1.visible', true)
			setProperty('iconP2.visible', true)
			setTextWidth('scoreText', 200)
			setTextAlignment('scoreText', 'right')
			debugPrint('Set HUD style to Vanilla-like')
		end
		
		if stringStartsWith(version, '0.6') then
			setProperty('timeBarBG.x', getProperty('healthBar.x') + 200)
			setProperty('timeBar.x', getProperty('healthBar.x') + 400)
			setProperty('timeTxt.x', getProperty('healthBar.x') + 192.5)
		elseif stringStartsWith(version, '0.7') then
			setProperty('timeBar.x', getProperty('healthBar.x') + 200)
			setProperty('timeTxt.x', getProperty('healthBar.x') + 195)
		end
		
		if downscroll then
			if stringStartsWith(version, '0.6') then
				setProperty('timeBarBG.y', getProperty('healthBar.y') + 10)
				setProperty('timeBar.y', getProperty('healthBar.y') + 20)
				setProperty('timeTxt.y', getProperty('healthBar.y') + 16)
			elseif stringStartsWith(version, '0.7') then
				setProperty('timeBar.y', getProperty('healthBar.y') + 10)
				setProperty('timeTxt.y', getProperty('healthBar.y') + 20)
			end
		end
		flushSaveData('shrimpleHUD')
	end
end

function onSongStart()
	if botPlay and not disableShrimpHUD then
		for i = 0,7 do
			noteTweenAlpha(i, i, 0.5, 1.25 / playbackRate)
		end
	end
end

function onUpdateScore()
	if not botPlay and not disableShrimpHUD then
		if getDataFromSave('shrimpleHUD', 'hudStyle') == 'vanilla' then
			setTextString('scoreText', 'SCORE: '..score..' ['..ratingFC..']')
		elseif getDataFromSave('shrimpleHUD', 'hudStyle') == 'shrimple' then
			setTextString('scoreText', 'SCORE: '..score..'\nACCURACY: '..round((getProperty('ratingPercent') * 100), 2)..'% ['..ratingFC..']\nMISSES: '..misses..'')
		end
	end
end

function round(x, n)
	n = math.pow(10, n or 0)
	x = x * n
	if x >= 0 then x = math.floor(x + 0.5) else x = math.ceil(x - 0.5) end
	return x / n
end