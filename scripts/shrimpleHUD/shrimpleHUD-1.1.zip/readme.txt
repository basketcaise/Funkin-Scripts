Thanks for downloading shrimpleHUD!

Before I get into installation instructions... 
If you intend to use this for your mod or a video or whatever,
PLEASE credit me (Basketcaise/NoMoreNuzlocke) and leave a link back to the Gamebanana page.
I'd appreciate it!

Installation instructions:
Just place the script in either the scripts folder or the data folder of the song you want to use the HUD in.

If you don't have a specific mod you want to use the HUD in or you want to use the HUD in all mods, then just place the shrimpleHUDGlobal folder inside your Psych Engine mods folder.

Remember, this HUD was only tested on v0.7.1h and v0.6.3, any other versions may or may not work correctly with the HUD
I'd recommend using 0.7.1h though, cause it's just better. XDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD

Here's an example of what you can use to disable shrimpleHUD on specific songs:

function onCreate()
	setGlobalFromScript('mods/shrimpleHUDGlobal/scripts/shrimpleHUD.lua', 'disableShrimpHUD', true)
end

This only works if you have the global mod installed and it's named 'shrimpleHUDGlobal'
This can work literally anywhere if you have the right file path to the HUD script though