Thanks for downloading shrimpleHUD!

Before I get into installation instructions... 
If you intend to use this for your mod or a video or whatever,
PLEASE credit me (Basketcaise/NoMoreNuzlocke) and leave a link back to the Gamebanana page.
I'd appreciate it!
you don't need to ask for permission to use it if you credit me ;)

Installation instructions:
Just place the script in either the scripts folder or the data folder of the song you want to use the HUD in.

If you don't have a specific mod you want to use the HUD in or you want to use the HUD in all mods, then just place the shrimpleHUDGlobal folder inside your Psych Engine mods folder.

Remember, this HUD only works on versions 0.7 and above!
I'd recommend using 0.7.1h though, cause it's just better. XDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD