function onCreatePost() -- sorry for the messy code i wrote most of this at 3 am lmao
	initSaveData('shrimpleHUD', 'hudStyle')
	
	if getDataFromSave('shrimpleHUD', 'hudStyle') == null then
		setDataFromSave('shrimpleHUD', 'hudStyle', 'vanilla')
		flushSaveData('shrimpleHUD')
	end
	
	if getDataFromSave('shrimpleHUD', 'hudStyle') == 'vanilla' then
		makeLuaText('scoreText', 'SCORE: '..score..' ['..ratingFC..']', 200, getProperty('healthBar.x') + 402.5, getProperty('healthBar.y') - 20)
		setTextAlignment('scoreText', 'right')
	elseif getDataFromSave('shrimpleHUD', 'hudStyle') == 'custom' then
		if downscroll then
			setProperty('healthBar.y', 35.75)
		else
			setProperty('healthBar.y', 684.25)
		end
		
		setProperty('iconP1.visible', false)
		setProperty('iconP2.visible', false)
		
		makeLuaText('scoreText', 'SCORE: '..score..'\nACCURACY: ? ['..ratingFC..']\nMISSES: '..misses..'', 0, getProperty('healthBar.x'), getProperty('healthBar.y') + 20)
		setTextAlignment('scoreText', 'left')
	end
	setProperty('scoreTxt.visible', false)
	
	scaleObject('timeBar', 0.5, 1)
	setObjectOrder('timeBar', getObjectOrder('iconP1') + 1)
	setProperty('timeBar.x', getProperty('healthBar.x') + 200)
	setProperty('timeBar.y', getProperty('healthBar.y') + 10)
	
	setObjectOrder('timeTxt', getObjectOrder('timeBar') + 1)
	setProperty('timeTxt.x', getProperty('healthBar.x') + 195)
	setProperty('timeTxt.y', getProperty('healthBar.y') + 20)
	
	if getDataFromSave('shrimpleHUD', 'hudStyle') == 'custom' and not downscroll then
		setProperty('timeBar.y', getProperty('healthBar.y') - 30)
		setProperty('timeTxt.y', getProperty('healthBar.y') - 20)
		if botPlay then
			setProperty('scoreText.y', getProperty('healthBar.y') - 20)
		else
			setProperty('scoreText.y', getProperty('healthBar.y') - 50)
		end
	end
	
	if botPlay then
		setProperty('grpNoteSplashes.visible', false)
		setProperty('showComboNum', false)
		setProperty('showRating', false)
		setProperty('botplayTxt.visible', false)
		setTextString('scoreText', '[BOTPLAY]')
	end
	
	addLuaText('scoreText')
	setTextAlignment('timeTxt', 'right')
	setTextSize('timeTxt', getTextSize('scoreText'))
end

function onUpdate()
	if keyboardJustPressed('NINE') then
		if getDataFromSave('shrimpleHUD', 'hudStyle') == 'vanilla' then
			if downscroll then
				setProperty('healthBar.y', 35.75)
				setProperty('scoreText.y', getProperty('healthBar.y') + 20)
			else
				setProperty('healthBar.y', 684.25)
				setProperty('timeBar.y', getProperty('healthBar.y') - 30)
				setProperty('timeTxt.y', getProperty('healthBar.y') - 20)
				
				if botPlay then
					setProperty('scoreText.y', getProperty('healthBar.y') - 20)
				else
					setProperty('scoreText.y', getProperty('healthBar.y') - 50)
				end
			end
			
			if not botPlay then
				setTextString('scoreText', 'SCORE: '..score..'\nACCURACY: '..round((getProperty('ratingPercent') * 100), 2)..'% ['..ratingFC..']\nMISSES: '..misses..'')
			end
			
			setDataFromSave('shrimpleHUD', 'hudStyle', 'custom')
			setProperty('iconP1.visible', false)
			setProperty('iconP2.visible', false)
			setProperty('scoreText.x', getProperty('healthBar.x'))
			setTextWidth('scoreText', 0)
			setTextAlignment('scoreText', 'left')
			debugPrint('Set HUD style to Customized')
		elseif getDataFromSave('shrimpleHUD', 'hudStyle') == 'custom' then
			if downscroll then
				setProperty('healthBar.y', 79.2)
			else
				setProperty('healthBar.y', 640.8)
			end
			
			if not botPlay then
				setTextString('scoreText', 'SCORE: '..score..' ['..ratingFC..']')
			end
			
			setDataFromSave('shrimpleHUD', 'hudStyle', 'vanilla')
			setProperty('iconP1.visible', true)
			setProperty('iconP2.visible', true)
			setProperty('scoreText.x', getProperty('healthBar.x') + 402.5)
			setProperty('scoreText.y', getProperty('healthBar.y') - 20)
			setTextWidth('scoreText', 200)
			setTextAlignment('scoreText', 'right')
			debugPrint('Set HUD style to Vanilla-like')
		end
		setProperty('timeBar.x', getProperty('healthBar.x') + 200)
		setProperty('timeTxt.x', getProperty('healthBar.x') + 195)
		
		if downscroll then
			setProperty('timeBar.y', getProperty('healthBar.y') + 10)
			setProperty('timeTxt.y', getProperty('healthBar.y') + 20)
		end
	end
end

function onSongStart()
	if botPlay then
		for i = 0,7 do
			noteTweenAlpha(i, i, 0.5, 1 / playbackRate)
		end
	end
end

function onUpdateScore()
	if not botPlay then
		if getDataFromSave('shrimpleHUD', 'hudStyle') == 'vanilla' then
			setTextString('scoreText', 'SCORE: '..score..' ['..ratingFC..']')
		elseif getDataFromSave('shrimpleHUD', 'hudStyle') == 'custom' then
			setTextString('scoreText', 'SCORE: '..score..'\nACCURACY: '..round((getProperty('ratingPercent') * 100), 2)..'% ['..ratingFC..']\nMISSES: '..misses..'')
		end
	end
end

function noteMiss()
	if not botPlay then
		if getDataFromSave('shrimpleHUD', 'hudStyle') == 'vanilla' then
			setTextString('scoreText', 'SCORE: '..score..' ['..ratingFC..']')
		elseif getDataFromSave('shrimpleHUD', 'hudStyle') == 'custom' then
			setTextString('scoreText', 'SCORE: '..score..'\nACCURACY: '..round((getProperty('ratingPercent') * 100), 2)..'% ['..ratingFC..']\nMISSES: '..misses..'')
		end
	end
end

function round(x, n)
	n = math.pow(10, n or 0)
	x = x * n
	if x >= 0 then x = math.floor(x + 0.5) else x = math.ceil(x - 0.5) end
	return x / n
end